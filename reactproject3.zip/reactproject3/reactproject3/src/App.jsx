﻿import React, { useState, useEffect, useMemo, useCallback } from "react";
import "./App.css";
import SearchBar from "./SearchBar";
import UserList from "./UserList";
import UserDetail from "./UserDetail";
import FunCube from "./FunCube";

function App() {
    // Data & loading state.
    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(true);

    const [searchInputs, setSearchInputs] = useState({
        name: "",
        email: "",
        company: "",
        city: "",
        phone: "",
    });
    const [filters, setFilters] = useState({
        name: "",
        email: "",
        company: "",
        city: "",
        phone: "",
    });

    const [resetKey, setResetKey] = useState(0);

    const [selectedUser, setSelectedUser] = useState(null);
    const [cubes, setCubes] = useState([]);

    useEffect(() => {
        fetch("https://jsonplaceholder.typicode.com/users")
            .then((resp) => resp.json())
            .then((data) => {
                setUsers(data);
                setLoading(false);
            })
            .catch((err) => {
                console.error("Error fetching users:", err);
                setLoading(false);
            });
    }, []);

    const handleInputChange = useCallback((e) => {
        const { name, value } = e.target;
        setSearchInputs((prev) => ({ ...prev, [name]: value }));
    }, []);

    const handleSearch = useCallback(() => {
        setFilters(searchInputs);
    }, [searchInputs]);


    const handleClear = useCallback(() => {
        const cleared = { name: "", email: "", company: "", city: "", phone: "" };
        setSearchInputs(cleared);
        setFilters(cleared);
        setCubes([]);
        setResetKey((prev) => prev + 1);
    }, []);

    const handleUserClick = useCallback((user) => {
        setSelectedUser(user);
    }, []);


    const handleExplode = useCallback((user, dropX) => {
        setCubes((prev) => [
            ...prev,
            { id: user.id, username: user.name, initialX: dropX },
        ]);
    }, []);

    const filteredUsers = useMemo(() => {
        return users.filter((user) => {
            let matches = true;
            if (filters.name) {
                matches =
                    matches &&
                    user.name.toLowerCase().includes(filters.name.toLowerCase());
            }
            if (filters.email) {
                const emailQuery = filters.email.toLowerCase();
                const emailLower = user.email.toLowerCase();
                matches =
                    matches &&
                    (emailQuery.startsWith(".")
                        ? emailLower.endsWith(emailQuery)
                        : emailLower.includes(emailQuery));
            }
            if (filters.company) {
                matches =
                    matches &&
                    user.company.name
                        .toLowerCase()
                        .includes(filters.company.toLowerCase());
            }
            if (filters.city) {
                matches =
                    matches &&
                    user.address.city
                        .toLowerCase()
                        .includes(filters.city.toLowerCase());
            }
            if (filters.phone) {
                const phoneQuery = filters.phone;
                if (/^\d{3}$/.test(phoneQuery)) {
                    const phoneDigits = user.phone.replace(/\D/g, "");
                    matches = matches && phoneDigits.endsWith(phoneQuery);
                } else {
                    matches =
                        matches &&
                        user.phone.toLowerCase().includes(phoneQuery.toLowerCase());
                }
            }
            return matches;
        });
    }, [users, filters]);

    return (
        <div className="App">
            <h1>User Search</h1>
            <div className="content-container">
                <div className="left-pane">
                    <SearchBar
                        searchInputs={searchInputs}
                        onInputChange={handleInputChange}
                        onSearch={handleSearch}
                        onClear={handleClear}
                    />
                    {loading ? (
                        <p className="status-message">Loading...</p>
                    ) : filteredUsers.length > 0 ? (
                        <UserList
                            key={resetKey}
                            users={filteredUsers}
                            onUserClick={handleUserClick}
                            onExplode={handleExplode}
                            resetKey={resetKey}
                        />
                    ) : (
                        <p className="status-message">No results found</p>
                    )}
                </div>
                <div className="details-pane">
                    <UserDetail user={selectedUser} />
                </div>
            </div>
            <div className="cube-container">
                {cubes.map((cube) => (
                    <FunCube key={cube.id} cube={cube} />
                ))}
            </div>
        </div>
    );
}

export default App;
