import React from "react";
import "./App.css";

function SearchBar({ searchInputs, onInputChange, onSearch, onClear }) {
    return (
        <div className="search-container">
            <div className="search-row">
                <div className="search-field">
                    <label>Name</label>
                    <input
                        type="text"
                        name="name"
                        placeholder="Search Name..."
                        value={searchInputs.name}
                        onChange={onInputChange}
                    />
                </div>
                <div className="search-field">
                    <label>Phone</label>
                    <input
                        type="text"
                        name="phone"
                        placeholder="Search Phone..."
                        value={searchInputs.phone}
                        onChange={onInputChange}
                    />
                </div>
            </div>
            <div className="search-row">
                <div className="search-field">
                    <label>Email</label>
                    <input
                        type="text"
                        name="email"
                        placeholder="Search Email (e.g., .net)"
                        value={searchInputs.email}
                        onChange={onInputChange}
                    />
                </div>
                <div className="search-field">
                    <label>Company</label>
                    <input
                        type="text"
                        name="company"
                        placeholder="Search Company..."
                        value={searchInputs.company}
                        onChange={onInputChange}
                    />
                </div>
            </div>
            <div className="search-row">
                <div className="search-field full-width">
                    <label>City</label>
                    <input
                        type="text"
                        name="city"
                        placeholder="Search City..."
                        value={searchInputs.city}
                        onChange={onInputChange}
                    />
                </div>
            </div>
            <div className="search-buttons">
                <button onClick={onSearch}>Search</button>
                <button onClick={onClear}>Clear</button>
            </div>
        </div>
    );
}

export default SearchBar;
