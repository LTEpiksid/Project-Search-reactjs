﻿import React, { useState, useEffect, useMemo, useCallback } from "react";
import { faker } from "@faker-js/faker";
import "./App.css";
import SearchBar from "./SearchBar";
import UserList from "./UserList";
import UserDetail from "./UserDetail";
import FunCube from "./FunCube";

function App() {
    // -----------------------------
    // Data & Loading State
    // -----------------------------
    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(true);

    // -----------------------------
    // Search Inputs & Filters
    // -----------------------------
    const [searchInputs, setSearchInputs] = useState({
        name: "",
        email: "",
        company: "",
        city: "",
        phone: "",
    });
    const [filters, setFilters] = useState({
        name: "",
        email: "",
        company: "",
        city: "",
        phone: "",
    });

    // -----------------------------
    // Selected User / FunCube State
    // -----------------------------
    const [selectedUser, setSelectedUser] = useState(null);
    const [cubes, setCubes] = useState([]);
    const [resetKey, setResetKey] = useState(0);

    // -----------------------------
    // Pagination State
    // -----------------------------
    const usersPerPage = 5;
    const [currentPage, setCurrentPage] = useState(1);

    // -----------------------------
    // Generate Fake Users with Faker
    // -----------------------------
    useEffect(() => {
        const generatedUsers = Array.from({ length: 100 }, (_, index) => ({
            id: index + 1,
            name: faker.person.fullName(),
            username: faker.internet.userName(),
            email: faker.internet.email(),
            address: {
                street: faker.location.streetAddress(),
                suite: `Apt. ${faker.number.int({ max: 1000 })}`,
                city: faker.location.city(),
                zipcode: faker.location.zipCode(),
                geo: {
                    lat: faker.location.latitude(),
                    lng: faker.location.longitude(),
                },
            },
            phone: faker.phone.number(),
            website: faker.internet.domainName(),
            company: {
                name: faker.company.name(),
                catchPhrase: faker.company.catchPhrase(),
                bs: faker.company.buzzPhrase(),
            },
        }));

        setUsers(generatedUsers);
        setLoading(false);
    }, []);

    // -----------------------------
    // Search Handlers
    // -----------------------------
    const handleInputChange = useCallback((e) => {
        const { name, value } = e.target;
        setSearchInputs((prev) => ({ ...prev, [name]: value }));
    }, []);

    const handleSearch = useCallback(() => {
        setFilters(searchInputs);
        setCurrentPage(1);
    }, [searchInputs]);

    const handleClear = useCallback(() => {
        const cleared = { name: "", email: "", company: "", city: "", phone: "" };
        setSearchInputs(cleared);
        setFilters(cleared);
        setCubes([]);
        setResetKey((prev) => prev + 1);
        setCurrentPage(1);
    }, []);

    // -----------------------------
    // User Interaction Handlers
    // -----------------------------
    const handleUserClick = useCallback((user) => {
        setSelectedUser(user);
    }, []);

    const handleExplode = useCallback((user, dropX) => {
        setCubes((prev) => [
            ...prev,
            { id: user.id, username: user.name, initialX: dropX },
        ]);
    }, []);

    // -----------------------------
    // Filtered Users Calculation
    // -----------------------------
    const filteredUsers = useMemo(() => {
        return users.filter((user) => {
            let matches = true;
            if (filters.name) {
                matches = matches && user.name.toLowerCase().includes(filters.name.toLowerCase());
            }
            if (filters.email) {
                const emailQuery = filters.email.toLowerCase();
                const emailLower = user.email.toLowerCase();
                matches = matches && (emailQuery.startsWith(".")
                    ? emailLower.endsWith(emailQuery)
                    : emailLower.includes(emailQuery));
            }
            if (filters.company) {
                matches = matches && user.company.name.toLowerCase().includes(filters.company.toLowerCase());
            }
            if (filters.city) {
                matches = matches && user.address.city.toLowerCase().includes(filters.city.toLowerCase());
            }
            if (filters.phone) {
                const phoneQuery = filters.phone;
                if (/^\d{3}$/.test(phoneQuery)) {
                    const phoneDigits = user.phone.replace(/\D/g, "");
                    matches = matches && phoneDigits.endsWith(phoneQuery);
                } else {
                    matches = matches && user.phone.toLowerCase().includes(phoneQuery.toLowerCase());
                }
            }
            return matches;
        });
    }, [users, filters]);

    // -----------------------------
    // Pagination Calculations
    // -----------------------------
    const totalPages = Math.ceil(filteredUsers.length / usersPerPage);
    const currentUsers = filteredUsers.slice(
        (currentPage - 1) * usersPerPage,
        currentPage * usersPerPage
    );

    const handleNextPage = () => {
        if (currentPage < totalPages) setCurrentPage(prev => prev + 1);
    };

    const handlePrevPage = () => {
        if (currentPage > 1) setCurrentPage(prev => prev - 1);
    };

    // -----------------------------
    // Render
    // -----------------------------
    return (
        <div className="App">
            <h1>User Search</h1>
            <div className="content-container">
                <div className="left-pane">
                    <SearchBar
                        searchInputs={searchInputs}
                        onInputChange={handleInputChange}
                        onSearch={handleSearch}
                        onClear={handleClear}
                    />
                    {loading ? (
                        <p className="status-message">Loading...</p>
                    ) : filteredUsers.length > 0 ? (
                        <>
                            <UserList
                                key={resetKey}
                                users={currentUsers}
                                onUserClick={handleUserClick}
                                onExplode={handleExplode}
                                resetKey={resetKey}
                            />
                            <div className="pagination">
                                <button onClick={handlePrevPage} disabled={currentPage === 1}>
                                    Previous
                                </button>
                                <span>Page {currentPage} of {totalPages}</span>
                                <button onClick={handleNextPage} disabled={currentPage === totalPages}>
                                    Next
                                </button>
                            </div>
                        </>
                    ) : (
                        <p className="status-message">No results found</p>
                    )}
                </div>
                <div className="details-pane">
                    <UserDetail user={selectedUser} />
                </div>
            </div>
            <div className="cube-container">
                {cubes.map((cube) => (
                    <FunCube key={cube.id} cube={cube} />
                ))}
            </div>
        </div>
    );
}

export default App;