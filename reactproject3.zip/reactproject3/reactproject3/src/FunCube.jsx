import React, { useState, useEffect } from "react";
import "./App.css";

function FunCube({ cube }) {
    const { username, initialX } = cube;

    // Generate a random cube size between 60 and 120 pixels.
    const [cubeSize] = useState(() =>
        Math.floor(Math.random() * (120 - 60 + 1)) + 60
    );

    // Generate a random shade of orange by keeping hue=30, saturation=100% and randomizing lightness between 50% and 70%.
    const [cubeColor] = useState(() => {
        const lightness = Math.floor(Math.random() * 21) + 50; // gives a value between 50 and 70
        return `hsl(30, 100%, ${lightness}%)`;
    });

    const [left, setLeft] = useState(initialX);
    const [fallen, setFallen] = useState(false);

    // Trigger a falling effect shortly after mounting.
    useEffect(() => {
        const timer = setTimeout(() => {
            setFallen(true);
        }, 100);
        return () => clearTimeout(timer);
    }, []);

    // Every second, sometimes move the cube a random amount.
    useEffect(() => {
        const moveInterval = setInterval(() => {
            if (Math.random() < 0.5) {
                return;
            }
            setLeft((prevLeft) => {
                const offset = Math.random() * 80 - 40; // random value between -40 and 40
                let newLeft = prevLeft + offset;
                const containerWidth = window.innerWidth;
                if (newLeft < 0) newLeft = 0;
                if (newLeft > containerWidth - cubeSize) newLeft = containerWidth - cubeSize;
                return newLeft;
            });
        }, 1000);
        return () => clearInterval(moveInterval);
    }, [cubeSize]);

    return (
        <div
            className="fun-cube"
            style={{
                left: left,
                bottom: fallen ? 0 : "100%",
                width: cubeSize,
                height: cubeSize,
            }}
        >
            {/* The user's name font size is proportional to the cube's size */}
            <div className="cube-label" style={{ fontSize: cubeSize / 4 }}>
                {username}
            </div>
            <div
                className="cube-box"
                style={{
                    backgroundColor: cubeColor,
                    width: cubeSize,
                    height: cubeSize,
                }}
            ></div>
        </div>
    );
}

export default FunCube;
