import React from "react";
import UserCard from "./UserCard";

function UserList({ users, onUserClick, onExplode, resetKey }) {
    return (
        <div className="user-list">
            {users.map((user) => (
                <UserCard
                    key={user.id + "-" + resetKey}
                    user={user}
                    onUserClick={onUserClick}
                    onExplode={onExplode}
                    resetKey={resetKey}
                />
            ))}
        </div>
    );
}

export default UserList;
