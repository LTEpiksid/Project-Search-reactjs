import React from "react";
import "./App.css";

function UserDetail({ user }) {
    if (!user) {
        return (
            <p className="status-message">
                Click on a user to see more details.
            </p>
        );
    }
    return (
        <div className="user-detail">
            <h2>{user.name}</h2>
            <p><strong>Username:</strong> {user.username}</p>
            <p><strong>Email:</strong> {user.email}</p>
            <p><strong>City:</strong> {user.address.city}</p>
            <p><strong>Phone:</strong> {user.phone}</p>
            <p><strong>Website:</strong> {user.website}</p>
            <p><strong>Company:</strong> {user.company.name}</p>
            <p><strong>CatchPhrase:</strong> {user.company.catchPhrase}</p>
            <p><strong>Business:</strong> {user.company.bs}</p>
            <p>
                <strong>Address:</strong> {user.address.street}, {user.address.suite},{" "}
                {user.address.city}, {user.address.zipcode}
            </p>
        </div>
    );
}

export default UserDetail;
