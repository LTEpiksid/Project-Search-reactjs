import React, { useState, useRef, useEffect } from "react";
import "./App.css";

function UserCard({ user, onUserClick, onExplode, resetKey }) {
    const [isDragging, setIsDragging] = useState(false);
    const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
    const [scale, setScale] = useState(1);
    const [exploded, setExploded] = useState(false);
    const cardRef = useRef(null);
    const startPosRef = useRef({ x: 0, y: 0 });

    // Reset local state when resetKey changes
    useEffect(() => {
        setExploded(false);
        setDragOffset({ x: 0, y: 0 });
        setScale(1);
    }, [resetKey]);

    const handlePointerDown = (e) => {
        e.preventDefault();
        setIsDragging(true);
        startPosRef.current = { x: e.clientX, y: e.clientY };
        e.currentTarget.setPointerCapture(e.pointerId);
    };

    const handlePointerMove = (e) => {
        if (!isDragging) return;
        const dx = e.clientX - startPosRef.current.x;
        const dy = e.clientY - startPosRef.current.y;
        setDragOffset({ x: dx, y: dy });

        const windowWidth = window.innerWidth;
        if (e.clientX > windowWidth / 2) {
            const extra = e.clientX - windowWidth / 2;
            setScale(Math.max(0.3, 1 - extra / windowWidth));
        } else {
            setScale(1);
        }
    };

    const handlePointerUp = (e) => {
        setIsDragging(false);
        e.currentTarget.releasePointerCapture(e.pointerId);
        const windowWidth = window.innerWidth;
        if (e.clientX <= windowWidth / 2) {
            // Left half: bounce back.
            setDragOffset({ x: 0, y: 0 });
            setScale(1);
            if (
                Math.abs(e.clientX - startPosRef.current.x) < 5 &&
                Math.abs(e.clientY - startPosRef.current.y) < 5
            ) {
                onUserClick(user);
            }
        } else {
            // Right half: trigger explosion at the current dragged location.
            setExploded(true);
            if (onExplode) {
                onExplode(user, e.clientX);
            }
        }
    };

    if (exploded) {
        // Position the explosion at the final drag offset.
        const explosionStyle = {
            transform: `translate3d(${dragOffset.x}px, ${dragOffset.y}px, 0)`,
        };

        // Render a randomized burst of 20 particles.
        const particleCount = 20;
        const particles = Array.from({ length: particleCount }).map(() => ({
            offsetX: (Math.random() - 0.5) * 80,
            offsetY: (Math.random() - 0.5) * 80,
            delay: Math.random() * 0.3,
        }));
        return (
            <div className="explosion-container" style={explosionStyle}>
                {particles.map((p, idx) => (
                    <div
                        key={idx}
                        className="particle"
                        style={{
                            transform: `translate3d(${p.offsetX}px, ${p.offsetY}px, 0)`,
                            animationDelay: `${p.delay}s`,
                        }}
                    />
                ))}
            </div>
        );
    }

    return (
        <div
            ref={cardRef}
            className="user-card"
            onPointerDown={handlePointerDown}
            onPointerMove={handlePointerMove}
            onPointerUp={handlePointerUp}
            style={{
                transform: `translate3d(${dragOffset.x}px, ${dragOffset.y}px, 0) scale(${scale})`,
                transition: isDragging ? "none" : "transform 0.3s ease-out",
                cursor: "grab",
                willChange: "transform",
                touchAction: "none",
            }}
        >
            <h3>{user.name}</h3>
            <p>Email: {user.email}</p>
            <p>City: {user.address.city}</p>
            <p>Company: {user.company.name}</p>
            <p>Phone: {user.phone}</p>
        </div>
    );
}

export default React.memo(UserCard);
